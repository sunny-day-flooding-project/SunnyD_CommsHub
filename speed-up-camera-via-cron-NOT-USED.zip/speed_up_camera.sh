#!/bin/bash
#set -x

# test if the file savedcron exists and save it if it does not
if ! test -f /home/pi/bin/savedcron; then
	crontab -l > /home/pi/bin/savedcron
fi

at -f /home/pi/bin/append_to_cron.sh 1830 Jul 21	# one minute images start at this time and date
echo "crontab savedcron" |        at 2030 Jul 21	# original schedule restored at this time and date

at -f /home/pi/bin/append_to_cron.sh 1930 Jul 22
echo "crontab savedcron" |        at 2130 Jul 22

