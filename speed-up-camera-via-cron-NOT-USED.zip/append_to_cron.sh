#!/bin/bash
set -x

cp savedcron appendedcron
echo "* * * * * /home/pi/bin/webcam.sh 2>&1" >> appendedcron
crontab appendedcron
